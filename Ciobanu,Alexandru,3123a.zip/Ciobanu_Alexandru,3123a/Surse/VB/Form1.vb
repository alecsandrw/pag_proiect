﻿Public Class Form1
    Dim IsDraggingForm As Boolean = False
    Public x As Integer = 0
    Dim n As Integer = 50
    Public st(50) As Integer
    Public stx As Integer
    Public credit As Integer = 50
    Public a(20, 6) As Integer
    Public b(20) As Integer
    Public final(6) As Integer
    Dim rand As Integer
    Private MousePos As New System.Drawing.Point(0, 0)

    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = MouseButtons.Left Then
            IsDraggingForm = True
            MousePos = e.Location
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp
        If e.Button = MouseButtons.Left Then IsDraggingForm = False
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove
        If IsDraggingForm Then
            Dim temp As Point = New Point(Me.Location + (e.Location - MousePos))
            Me.Location = temp
            temp = Nothing
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PlaySystemSound()
        Dim Result As DialogResult
        Result = MessageBox.Show("Sigur vreți să închideți aplicația?", "-Loto-", MessageBoxButtons.YesNo)
        If Result = System.Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If credit > 4 Then
            Form2.Show()
        Else
            MessageBox.Show("Nu aveți credit suficient pentru a cumpăra!")

        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label3.Text = credit.ToString()
        Label5.Text = x.ToString()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Button2.Enabled = False
        Dim ok As Boolean
        final(0) = CInt(Int((49 * Rnd()) + 1))
        For x As Integer = 1 To 5
            ok = False
            Do
                Randomize()
                rand = CInt(Int((49 * Rnd()) + 1))
                Dim y As Integer = 0
                Do
                    If rand = final(y) Then
                        ok = True
                    Else
                        y += 1
                        ok = False
                    End If
                Loop While y < x And ok = False
            Loop While ok = True
            final(x) = rand
        Next
        For i As Integer = 1 To x
            For j As Integer = 0 To 5
                For k As Integer = 0 To 5
                    If a(i, j) = final(k) Then
                        b(i) += 1
                    End If
                Next
            Next
            credit += b(i) * 10
        Next
        Form3.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("Program realizat de Ciobanu Alexandru, grupa 3123a")
    End Sub
    Sub PlaySystemSound()
        My.Computer.Audio.PlaySystemSound( _
            System.Media.SystemSounds.Asterisk)
    End Sub
End Class

