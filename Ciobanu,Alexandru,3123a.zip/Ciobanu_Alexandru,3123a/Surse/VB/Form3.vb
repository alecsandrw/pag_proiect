﻿Public Class Form3
    Dim offset As Integer = 20
    Dim y As Integer = 19
    Dim n As Integer = 50
    Dim m As Integer = 3
    Dim arrButton(20) As Button
    Dim arrCheck(50) As CheckBox
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 1 To Form1.x
            If i = 10 Then
                m = 3
                y += 1
            End If
            arrButton(i) = New Button()
            arrButton(i).Text = "Varianta" + i.ToString()
            arrButton(i).Location = New Point(m * offset, y * offset)
            arrButton(i).AutoSize = True
            AddHandler arrButton(i).Click, AddressOf ClickFunct
            Me.Controls.Add(arrButton(i))
            m += 4
        Next

        Dim j As Integer = 6
        Dim p As Integer = 5
        Dim offset2 As Integer = 20
        For i As Integer = 1 To n - 1
            If i = 11 Or i = 21 Or i = 31 Or i = 41 Then
                j += 2
                p = 5
            End If

            arrCheck(i) = New CheckBox()
            arrCheck(i).Text = i.ToString()
            arrCheck(i).Location = New Point(p * (offset2 + 20), j * offset2)
            arrCheck(i).Appearance = Appearance.Button
            arrCheck(i).Enabled = False
            arrCheck(i).AutoSize = True
            Me.Controls.Add(arrCheck(i))
            p += 1
        Next
    End Sub

    Private Sub ClickFunct(sender As Object, e As EventArgs)
        For j As Integer = 1 To n - 1
            arrCheck(j).Checked = False
            arrCheck(j).BackColor = Color.Empty
            arrCheck(j).ForeColor = Color.Black
        Next
        For i As Integer = 1 To Form1.x
            If sender.text = "Varianta" + i.ToString() Then
                For j As Integer = 0 To 5
                    arrCheck(Form1.a(i, j)).Checked = True
                    arrCheck(Form1.a(i, j)).BackColor = Color.Blue
                    arrCheck(Form1.a(i, j)).ForeColor = Color.White
                    If j = 0 Then
                        Label5.Text = Form1.a(i, j)
                        Label12.Text = Form1.final(j)
                    End If
                    If j = 1 Then
                        Label6.Text = Form1.a(i, j)
                        Label16.Text = Form1.final(j)
                    End If
                    If j = 2 Then
                        Label7.Text = Form1.a(i, j)
                        Label17.Text = Form1.final(j)
                    End If
                    If j = 3 Then
                        Label8.Text = Form1.a(i, j)
                        Label18.Text = Form1.final(j)
                    End If
                    If j = 4 Then
                        Label9.Text = Form1.a(i, j)
                        Label19.Text = Form1.final(j)
                    End If
                    If j = 5 Then
                        Label10.Text = Form1.a(i, j)
                        Label20.Text = Form1.final(j)
                    End If
                Next
                Label15.Text = Form1.b(i) * 10.ToString()
                Label5.Visible = True
                Label6.Visible = True
                Label7.Visible = True
                Label8.Visible = True
                Label9.Visible = True
                Label10.Visible = True
                Label11.Visible = True
                Label12.Visible = True
                Label13.Visible = True
                Label14.Visible = True
                Label15.Visible = True
                Label16.Visible = True
                Label17.Visible = True
                Label18.Visible = True
                Label19.Visible = True
                Label20.Visible = True
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form4.Show()
        For i As Integer = 0 To Form1.x
            Form1.b(i) = 0
        Next
        Form1.x = 0
        Form1.Label3.Text = Form1.credit.ToString()
        Form1.Label5.Text = Form1.x.ToString()
        Form1.Button2.Enabled = True
        Form1.Button3.Enabled = False
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PrintForm1.Print()
    End Sub
End Class