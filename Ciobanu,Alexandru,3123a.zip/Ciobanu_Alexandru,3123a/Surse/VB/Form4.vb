﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Creditul tău este acum " + Form1.credit.ToString()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Form1.Label4.Text = "Felicitări! Te mai așteptăm!"
        Form1.Label5.Visible = False
        Form1.Label6.Visible = False
        Form1.Button2.Enabled = False
    End Sub
End Class