﻿Public Class Form2
    Dim n As Integer = 50
    Dim y As Integer = 0
    Public n1(6) As Integer
    Dim rand As Integer
    Dim a(20, 6) As Integer
    Dim sec As Integer
    Dim arrCheck(50) As CheckBox

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim offset As Integer = 20
        Dim j As Integer = 6
        Dim m As Integer = 5

        For i As Integer = 1 To n - 1
            If i = 11 Or i = 21 Or i = 31 Or i = 41 Then
                j += 2
                m = 5
            End If

            arrCheck(i) = New CheckBox()
            arrCheck(i).Text = i.ToString()
            arrCheck(i).Location = New Point(m * (offset + 20), j * offset)
            arrCheck(i).Appearance = Appearance.Button
            arrCheck(i).AutoSize = True
            Me.Controls.Add(arrCheck(i))
            AddHandler arrCheck(i).CheckStateChanged, AddressOf chkChangeFunct
            m += 1
        Next

    End Sub

    Private Sub chkChangeFunct(sender As Object, e As EventArgs)
        Dim stat As String = " "
        If y < 6 Then
            If sender.checked = True Then
                stat = "BIFAT"
                n1(y) = sender.text
                sender.backcolor = Color.Blue
                sender.forecolor = Color.White
                y += 1
            Else
                stat = "NEBIFAT"
                sender.backcolor = Color.Empty
                sender.forecolor = Color.Black
                n1(y) = 0
                y -= 1
            End If
        Else
            If sender.checked = False Then
                For i As Integer = 0 To y
                    If n1(i) = sender.text Then
                        stat = "NEBIFAT"
                        sender.backcolor = Color.Empty
                        sender.forecolor = Color.Black
                        y -= 1
                    End If
                Next
            Else
                sec = 0
                Timer1.Interval = 1000
                Timer1.Start()
                Label15.Text = "Numar maxim de numere bifate."
                Label15.Visible = True
                sender.checked = False
                stat = "NEBIFAT"
            End If
        End If
        If y = 6 Then
            Button1.Enabled = True
        Else
            Button1.Enabled = False
        End If
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Label5.Text = Form1.x.ToString()
        If Button1.Text = "Confirmă" Then
            Form1.x += 1
            Form1.credit -= 5
            Form1.Button3.Enabled = True
            Form1.Label3.Text = Form1.credit.ToString()
            If Form1.x = 1 Then
                Form1.Label6.Text = "bilet"
            Else
                Form1.Label6.Text = "bilete"
            End If
            If CheckBox1.Checked = True Then
                Dim ok As Boolean
                n1(0) = CInt(Int((49 * Rnd()) + 1))
                For x As Integer = 1 To 5
                    ok = False
                    Do
                        Randomize()
                        rand = CInt(Int((49 * Rnd()) + 1))
                        Dim y As Integer = 0
                        Do
                            If rand = n1(y) Then
                                ok = True
                            Else
                                y += 1
                                ok = False
                            End If
                        Loop While y < x And ok = False
                    Loop While ok = True
                    n1(x) = rand
                Next
                Button1.Text = "Închide"
                For i As Integer = 0 To 5
                    Form1.a(Form1.x, i) = n1(i)
                Next
                For i As Integer = 0 To 5
                    If i = 0 Then
                        Label5.Text = n1(i)
                    End If
                    If i = 1 Then
                        Label6.Text = n1(i)
                    End If
                    If i = 2 Then
                        Label7.Text = n1(i)
                    End If
                    If i = 3 Then
                        Label8.Text = n1(i)
                    End If
                    If i = 4 Then
                        Label9.Text = n1(i)
                    End If
                    If i = 5 Then
                        Label10.Text = n1(i)
                    End If
                Next
                Label5.Visible = True
                Label6.Visible = True
                Label7.Visible = True
                Label8.Visible = True
                Label9.Visible = True
                Label10.Visible = True
                Label11.Visible = True
                Label12.Visible = True
                Label14.Visible = True
                CheckBox1.Enabled = False
            Else
                For i As Integer = 0 To 5
                    If i = 0 Then
                        Label5.Text = n1(i)
                    End If
                    If i = 1 Then
                        Label6.Text = n1(i)
                    End If
                    If i = 2 Then
                        Label7.Text = n1(i)
                    End If
                    If i = 3 Then
                        Label8.Text = n1(i)
                    End If
                    If i = 4 Then
                        Label9.Text = n1(i)
                    End If
                    If i = 5 Then
                        Label10.Text = n1(i)
                    End If
                    Label5.Visible = True
                    Label6.Visible = True
                    Label7.Visible = True
                    Label8.Visible = True
                    Label9.Visible = True
                    Label10.Visible = True
                    Label11.Visible = True
                    Label12.Visible = True
                    Label14.Visible = True
                    CheckBox1.Enabled = False
                    For j As Integer = 1 To n - 1
                        arrCheck(j).Enabled = False
                    Next
                Next
                Button1.Text = "Închide"
                For i As Integer = 0 To 5
                    Form1.a(Form1.x, i) = n1(i)
                Next
            End If
        Else
            Me.Close()
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Button1.Enabled = True
            For j As Integer = 1 To n - 1
                arrCheck(j).Enabled = False
            Next
        Else
            If y < 6 Then
                Button1.Enabled = False
            End If

            For j As Integer = 1 To n - 1
                arrCheck(j).Enabled = True
            Next
            End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        sec += 1
        If sec = 2 Then
            Label15.Visible = False
            Timer1.Stop()
        End If
    End Sub

End Class